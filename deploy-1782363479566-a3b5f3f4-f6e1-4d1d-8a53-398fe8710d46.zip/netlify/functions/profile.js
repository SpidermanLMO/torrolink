// ================================================
// TORROLINK — PROFILE PAGE FUNCTION
// Serves the customer's public profile page at /p/:handle
// Full theme engine: patterns, dark mode, photo carousel, section controls
// ================================================

const { createClient } = require("@supabase/supabase-js");

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

exports.handler = async (event) => {
  try {
  const handle = event.path.replace(/^\/p\//, "").split("/")[0].toLowerCase();
  if (!handle) return { statusCode: 302, headers: { Location: "/" } };

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("handle", handle)
    .eq("is_active", true)
    .single();

  if (error || !profile) {
    return {
      statusCode: 404,
      headers: { "Content-Type": "text/html" },
      body: notFoundPage(handle),
    };
  }

  // Suspended profiles — show placeholder rather than blank 404
  if (profile.suspended) {
    return {
      statusCode: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body: suspendedPage(profile.business_name || handle),
    };
  }

  const { data: reviews } = await supabase
    .from("reviews")
    .select("id, reviewer_name, rating, review_text, is_featured, submitted_at")
    .eq("profile_id", profile.id)
    .eq("is_visible", true)
    .order("is_featured", { ascending: false })
    .order("submitted_at", { ascending: false })
    .limit(20);

  const [{ data: photos }, { data: documents }] = await Promise.all([
    supabase
      .from("profile_photos")
      .select("id, file_url, caption, view_count, sort_order")
      .eq("profile_id", profile.id)
      .order("sort_order"),
    supabase
      .from("profile_documents")
      .select("id, file_url, title, file_type, sort_order")
      .eq("profile_id", profile.id)
      .order("sort_order"),
  ]);

  return {
    statusCode: 200,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "public, s-maxage=60, stale-while-revalidate=120" },
    body: renderProfile(profile, reviews || [], photos || [], documents || []),
  };
  } catch (err) {
    console.error("[profile] unhandled error:", err && err.message ? err.message : err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "text/html; charset=utf-8" },
      body: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Error — TorroLink</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap" rel="stylesheet"/>
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#0f6b6b 0%,#1a2e4a 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;}
    .card{background:#fff;border-radius:24px;padding:48px 36px;max-width:420px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.25);}
    .icon{font-size:3rem;margin-bottom:16px;}
    h1{font-size:1.5rem;font-weight:800;color:#1a1a2e;margin-bottom:10px;}
    p{color:#666;font-size:0.95rem;line-height:1.5;margin-bottom:28px;}
    .btn{display:inline-block;background:#0f6b6b;color:#fff;font-weight:700;font-size:0.95rem;padding:13px 28px;border-radius:50px;text-decoration:none;}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">&#9888;&#65039;</div>
    <h1>Something went wrong</h1>
    <p>This profile couldn't load right now. Please try again in a moment.</p>
    <a href="https://torrolink.com" class="btn">Go to TorroLink</a>
  </div>
</body>
</html>`,
    };
  }
};

// ── THEME ENGINE ───────────────────────────────────────────────────────────────

function getThemeCSS(theme = {}, backgroundImage = null) {
  const pattern    = theme.pattern    || "solid";
  const color1     = theme.color1     || "#0f6b6b";
  const color2     = theme.color2     || "#0a4d4d";
  const darkMode   = theme.darkMode   || false;
  const cardStyle  = theme.cardStyle  || "rounded";

  const cardBg     = darkMode ? "#1a1a2e" : "#ffffff";
  const cardBorder = darkMode ? "#2d2d4a" : "#e5e5ea";
  const textPri    = darkMode ? "#f0f0f0" : "#1a1a2e";
  const textSec    = darkMode ? "#a0a0c0" : "#555577";
  const pageBg     = darkMode ? "#0e0e1a" : "#f5f7fa";
  const linkBg     = darkMode ? "#1f2f2f" : "#f0fafa";
  const linkBorder = darkMode ? "#2a4040" : "#d0eaea";
  const linkColor  = darkMode ? "#5ac8c8" : "#0f6b6b";
  const socBg      = darkMode ? "#1e1e30" : "#f7f7fa";
  const socBorder  = darkMode ? "#2d2d4a" : "#e5e5ea";
  const socColor   = darkMode ? "#d0d0f0" : "#333";
  const cardRadius = cardStyle === "sharp" ? "8px" : cardStyle === "pill" ? "28px" : "20px";

  const patterns = {
    solid: `background: ${color1};`,
    gradient: `background: linear-gradient(135deg, ${color1} 0%, ${color2} 100%);`,
    'camo': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><ellipse cx="45" cy="35" rx="55" ry="40" fill="rgba(0,0,0,0.42)" transform="rotate(-20,45,35)"/><ellipse cx="155" cy="80" rx="62" ry="44" fill="rgba(20,40,5,0.66)"/><ellipse cx="25" cy="158" rx="48" ry="64" fill="rgba(0,0,0,0.42)" transform="rotate(12,25,158)"/><ellipse cx="172" cy="168" rx="58" ry="40" fill="rgba(35,25,5,0.58)"/><ellipse cx="118" cy="28" rx="44" ry="58" fill="rgba(20,40,5,0.66)" transform="rotate(25,118,28)"/><ellipse cx="98" cy="118" rx="52" ry="38" fill="rgba(0,0,0,0.42)" transform="rotate(-8,98,118)"/><ellipse cx="162" cy="132" rx="36" ry="48" fill="rgba(35,25,5,0.58)" transform="rotate(18,162,132)"/></svg>'; return 'background-color:#4a5c2f;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'camo-desert': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><ellipse cx="45" cy="35" rx="55" ry="40" fill="rgba(107,76,42,0.6)" transform="rotate(-20,45,35)"/><ellipse cx="155" cy="80" rx="62" ry="44" fill="rgba(160,120,56,0.55)"/><ellipse cx="25" cy="158" rx="48" ry="64" fill="rgba(107,76,42,0.6)" transform="rotate(12,25,158)"/><ellipse cx="172" cy="168" rx="58" ry="40" fill="rgba(90,62,20,0.65)"/><ellipse cx="118" cy="28" rx="44" ry="58" fill="rgba(160,120,56,0.55)" transform="rotate(25,118,28)"/><ellipse cx="98" cy="118" rx="52" ry="38" fill="rgba(107,76,42,0.6)" transform="rotate(-8,98,118)"/><ellipse cx="162" cy="132" rx="36" ry="48" fill="rgba(90,62,20,0.65)" transform="rotate(18,162,132)"/></svg>'; return 'background-color:#c8a96e;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'camo-pink': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><ellipse cx="45" cy="35" rx="55" ry="40" fill="rgba(155,27,106,0.62)" transform="rotate(-20,45,35)"/><ellipse cx="155" cy="80" rx="62" ry="44" fill="rgba(219,39,119,0.55)"/><ellipse cx="25" cy="158" rx="48" ry="64" fill="rgba(155,27,106,0.62)" transform="rotate(12,25,158)"/><ellipse cx="172" cy="168" rx="58" ry="40" fill="rgba(109,0,80,0.65)"/><ellipse cx="118" cy="28" rx="44" ry="58" fill="rgba(219,39,119,0.55)" transform="rotate(25,118,28)"/><ellipse cx="98" cy="118" rx="52" ry="38" fill="rgba(155,27,106,0.62)" transform="rotate(-8,98,118)"/><ellipse cx="162" cy="132" rx="36" ry="48" fill="rgba(109,0,80,0.65)" transform="rotate(18,162,132)"/></svg>'; return 'background-color:#f472b6;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'camo-blue': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><ellipse cx="45" cy="35" rx="55" ry="40" fill="rgba(15,40,96,0.65)" transform="rotate(-20,45,35)"/><ellipse cx="155" cy="80" rx="62" ry="44" fill="rgba(45,92,170,0.55)"/><ellipse cx="25" cy="158" rx="48" ry="64" fill="rgba(15,40,96,0.65)" transform="rotate(12,25,158)"/><ellipse cx="172" cy="168" rx="58" ry="40" fill="rgba(10,24,80,0.7)"/><ellipse cx="118" cy="28" rx="44" ry="58" fill="rgba(45,92,170,0.55)" transform="rotate(25,118,28)"/><ellipse cx="98" cy="118" rx="52" ry="38" fill="rgba(15,40,96,0.65)" transform="rotate(-8,98,118)"/><ellipse cx="162" cy="132" rx="36" ry="48" fill="rgba(10,24,80,0.7)" transform="rotate(18,162,132)"/></svg>'; return 'background-color:#1e4080;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'camo-rwb': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><ellipse cx="45" cy="35" rx="55" ry="40" fill="rgba(29,78,216,0.65)" transform="rotate(-20,45,35)"/><ellipse cx="155" cy="80" rx="62" ry="44" fill="rgba(255,255,255,0.5)"/><ellipse cx="25" cy="158" rx="48" ry="64" fill="rgba(29,78,216,0.65)" transform="rotate(12,25,158)"/><ellipse cx="172" cy="168" rx="58" ry="40" fill="rgba(29,78,216,0.5)"/><ellipse cx="118" cy="28" rx="44" ry="58" fill="rgba(255,255,255,0.5)" transform="rotate(25,118,28)"/><ellipse cx="98" cy="118" rx="52" ry="38" fill="rgba(29,78,216,0.65)" transform="rotate(-8,98,118)"/><ellipse cx="162" cy="132" rx="36" ry="48" fill="rgba(29,78,216,0.5)" transform="rotate(18,162,132)"/></svg>'; return 'background-color:#b91c1c;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
    'leopard': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><ellipse cx="22" cy="20" rx="15" ry="11" fill="#3d1f00" opacity="0.93"/><ellipse cx="22" cy="20" rx="7" ry="5" fill="#c8952a" opacity="0.97"/><ellipse cx="72" cy="62" rx="11" ry="16" fill="#3d1f00" opacity="0.93" transform="rotate(22,72,62)"/><ellipse cx="72" cy="62" rx="5" ry="8" fill="#c8952a" opacity="0.97" transform="rotate(22,72,62)"/><ellipse cx="104" cy="18" rx="13" ry="10" fill="#3d1f00" opacity="0.93" transform="rotate(-18,104,18)"/><ellipse cx="104" cy="18" rx="6" ry="4.5" fill="#c8952a" opacity="0.97" transform="rotate(-18,104,18)"/><ellipse cx="28" cy="85" rx="10" ry="14" fill="#3d1f00" opacity="0.93" transform="rotate(12,28,85)"/><ellipse cx="28" cy="85" rx="4.5" ry="6.5" fill="#c8952a" opacity="0.97" transform="rotate(12,28,85)"/><ellipse cx="96" cy="88" rx="14" ry="10" fill="#3d1f00" opacity="0.93" transform="rotate(-28,96,88)"/><ellipse cx="96" cy="88" rx="6.5" ry="4.5" fill="#c8952a" opacity="0.97" transform="rotate(-28,96,88)"/><ellipse cx="52" cy="112" rx="12" ry="9" fill="#3d1f00" opacity="0.93"/><ellipse cx="52" cy="112" rx="5.5" ry="4" fill="#c8952a" opacity="0.97"/><ellipse cx="118" cy="108" rx="9" ry="13" fill="#3d1f00" opacity="0.93" transform="rotate(15,118,108)"/><ellipse cx="118" cy="108" rx="4" ry="6" fill="#c8952a" opacity="0.97" transform="rotate(15,118,108)"/></svg>'; return 'background-color:#c8952a;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:130px 130px;background-repeat:repeat;'; })(),
        'cheetah': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><ellipse cx="22" cy="20" rx="15" ry="11" fill="#1a1a1a" opacity="0.93"/><ellipse cx="22" cy="20" rx="7" ry="5" fill="#f5c518" opacity="0.97"/><ellipse cx="72" cy="62" rx="11" ry="16" fill="#1a1a1a" opacity="0.93" transform="rotate(22,72,62)"/><ellipse cx="72" cy="62" rx="5" ry="8" fill="#f5c518" opacity="0.97" transform="rotate(22,72,62)"/><ellipse cx="104" cy="18" rx="13" ry="10" fill="#1a1a1a" opacity="0.93" transform="rotate(-18,104,18)"/><ellipse cx="104" cy="18" rx="6" ry="4.5" fill="#f5c518" opacity="0.97" transform="rotate(-18,104,18)"/><ellipse cx="28" cy="85" rx="10" ry="14" fill="#1a1a1a" opacity="0.93" transform="rotate(12,28,85)"/><ellipse cx="28" cy="85" rx="4.5" ry="6.5" fill="#f5c518" opacity="0.97" transform="rotate(12,28,85)"/><ellipse cx="96" cy="88" rx="14" ry="10" fill="#1a1a1a" opacity="0.93" transform="rotate(-28,96,88)"/><ellipse cx="96" cy="88" rx="6.5" ry="4.5" fill="#f5c518" opacity="0.97" transform="rotate(-28,96,88)"/><ellipse cx="52" cy="112" rx="12" ry="9" fill="#1a1a1a" opacity="0.93"/><ellipse cx="52" cy="112" rx="5.5" ry="4" fill="#f5c518" opacity="0.97"/><ellipse cx="118" cy="108" rx="9" ry="13" fill="#1a1a1a" opacity="0.93" transform="rotate(15,118,108)"/><ellipse cx="118" cy="108" rx="4" ry="6" fill="#f5c518" opacity="0.97" transform="rotate(15,118,108)"/></svg>'; return 'background-color:#f5c518;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:130px 130px;background-repeat:repeat;'; })(),
        'leopard-pink': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><ellipse cx="22" cy="20" rx="15" ry="11" fill="#4a0032" opacity="0.93"/><ellipse cx="22" cy="20" rx="7" ry="5" fill="#ff69b4" opacity="0.97"/><ellipse cx="72" cy="62" rx="11" ry="16" fill="#4a0032" opacity="0.93" transform="rotate(22,72,62)"/><ellipse cx="72" cy="62" rx="5" ry="8" fill="#ff69b4" opacity="0.97" transform="rotate(22,72,62)"/><ellipse cx="104" cy="18" rx="13" ry="10" fill="#4a0032" opacity="0.93" transform="rotate(-18,104,18)"/><ellipse cx="104" cy="18" rx="6" ry="4.5" fill="#ff69b4" opacity="0.97" transform="rotate(-18,104,18)"/><ellipse cx="28" cy="85" rx="10" ry="14" fill="#4a0032" opacity="0.93" transform="rotate(12,28,85)"/><ellipse cx="28" cy="85" rx="4.5" ry="6.5" fill="#ff69b4" opacity="0.97" transform="rotate(12,28,85)"/><ellipse cx="96" cy="88" rx="14" ry="10" fill="#4a0032" opacity="0.93" transform="rotate(-28,96,88)"/><ellipse cx="96" cy="88" rx="6.5" ry="4.5" fill="#ff69b4" opacity="0.97" transform="rotate(-28,96,88)"/><ellipse cx="52" cy="112" rx="12" ry="9" fill="#4a0032" opacity="0.93"/><ellipse cx="52" cy="112" rx="5.5" ry="4" fill="#ff69b4" opacity="0.97"/><ellipse cx="118" cy="108" rx="9" ry="13" fill="#4a0032" opacity="0.93" transform="rotate(15,118,108)"/><ellipse cx="118" cy="108" rx="4" ry="6" fill="#ff69b4" opacity="0.97" transform="rotate(15,118,108)"/></svg>'; return 'background-color:#ff1493;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:130px 130px;background-repeat:repeat;'; })(),
        'leopard-snow': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><ellipse cx="22" cy="20" rx="15" ry="11" fill="#2a2a3a" opacity="0.93"/><ellipse cx="22" cy="20" rx="7" ry="5" fill="#e8e8f5" opacity="0.97"/><ellipse cx="72" cy="62" rx="11" ry="16" fill="#2a2a3a" opacity="0.93" transform="rotate(22,72,62)"/><ellipse cx="72" cy="62" rx="5" ry="8" fill="#e8e8f5" opacity="0.97" transform="rotate(22,72,62)"/><ellipse cx="104" cy="18" rx="13" ry="10" fill="#2a2a3a" opacity="0.93" transform="rotate(-18,104,18)"/><ellipse cx="104" cy="18" rx="6" ry="4.5" fill="#e8e8f5" opacity="0.97" transform="rotate(-18,104,18)"/><ellipse cx="28" cy="85" rx="10" ry="14" fill="#2a2a3a" opacity="0.93" transform="rotate(12,28,85)"/><ellipse cx="28" cy="85" rx="4.5" ry="6.5" fill="#e8e8f5" opacity="0.97" transform="rotate(12,28,85)"/><ellipse cx="96" cy="88" rx="14" ry="10" fill="#2a2a3a" opacity="0.93" transform="rotate(-28,96,88)"/><ellipse cx="96" cy="88" rx="6.5" ry="4.5" fill="#e8e8f5" opacity="0.97" transform="rotate(-28,96,88)"/><ellipse cx="52" cy="112" rx="12" ry="9" fill="#2a2a3a" opacity="0.93"/><ellipse cx="52" cy="112" rx="5.5" ry="4" fill="#e8e8f5" opacity="0.97"/><ellipse cx="118" cy="108" rx="9" ry="13" fill="#2a2a3a" opacity="0.93" transform="rotate(15,118,108)"/><ellipse cx="118" cy="108" rx="4" ry="6" fill="#e8e8f5" opacity="0.97" transform="rotate(15,118,108)"/></svg>'; return 'background-color:#f0f0f8;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:130px 130px;background-repeat:repeat;'; })(),
        'leopard-rwb': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="130" height="130"><ellipse cx="22" cy="20" rx="15" ry="11" fill="#1e3a8a" opacity="0.93"/><ellipse cx="22" cy="20" rx="7" ry="5" fill="#ffffff" opacity="0.97"/><ellipse cx="72" cy="62" rx="11" ry="16" fill="#1e3a8a" opacity="0.93" transform="rotate(22,72,62)"/><ellipse cx="72" cy="62" rx="5" ry="8" fill="#ffffff" opacity="0.97" transform="rotate(22,72,62)"/><ellipse cx="104" cy="18" rx="13" ry="10" fill="#1e3a8a" opacity="0.93" transform="rotate(-18,104,18)"/><ellipse cx="104" cy="18" rx="6" ry="4.5" fill="#ffffff" opacity="0.97" transform="rotate(-18,104,18)"/><ellipse cx="28" cy="85" rx="10" ry="14" fill="#1e3a8a" opacity="0.93" transform="rotate(12,28,85)"/><ellipse cx="28" cy="85" rx="4.5" ry="6.5" fill="#ffffff" opacity="0.97" transform="rotate(12,28,85)"/><ellipse cx="96" cy="88" rx="14" ry="10" fill="#1e3a8a" opacity="0.93" transform="rotate(-28,96,88)"/><ellipse cx="96" cy="88" rx="6.5" ry="4.5" fill="#ffffff" opacity="0.97" transform="rotate(-28,96,88)"/><ellipse cx="52" cy="112" rx="12" ry="9" fill="#1e3a8a" opacity="0.93"/><ellipse cx="52" cy="112" rx="5.5" ry="4" fill="#ffffff" opacity="0.97"/><ellipse cx="118" cy="108" rx="9" ry="13" fill="#1e3a8a" opacity="0.93" transform="rotate(15,118,108)"/><ellipse cx="118" cy="108" rx="4" ry="6" fill="#ffffff" opacity="0.97" transform="rotate(15,118,108)"/></svg>'; return 'background-color:#dc2626;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:130px 130px;background-repeat:repeat;'; })(),
    'tropical': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><ellipse cx="-5" cy="110" rx="20" ry="88" fill="rgba(0,145,55,0.88)" transform="rotate(-38,-5,110)"/><ellipse cx="225" cy="85" rx="17" ry="78" fill="rgba(0,165,65,0.82)" transform="rotate(42,225,85)"/><ellipse cx="110" cy="225" rx="16" ry="82" fill="rgba(0,145,55,0.88)" transform="rotate(16,110,225)"/><ellipse cx="35" cy="-5" rx="13" ry="70" fill="rgba(0,165,65,0.82)" transform="rotate(-22,35,-5)"/><ellipse cx="185" cy="220" rx="18" ry="80" fill="rgba(0,145,55,0.88)" transform="rotate(32,185,220)"/><circle cx="78" cy="68" r="15" fill="rgba(255,55,100,0.92)" opacity="0.95"/><circle cx="78" cy="68" r="5.5" fill="rgba(255,210,0,0.97)" opacity="0.97"/><circle cx="152" cy="152" r="13" fill="rgba(255,140,0,0.9)" opacity="0.9"/><circle cx="152" cy="152" r="5" fill="rgba(255,235,0,0.97)" opacity="0.97"/><circle cx="118" cy="28" r="8" fill="rgba(255,55,100,0.92)" opacity="0.85"/><circle cx="118" cy="28" r="3" fill="rgba(255,210,0,0.97)" opacity="0.95"/></svg>'; return 'background-color:#1a6b38;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'tropical-neon': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><ellipse cx="-5" cy="110" rx="20" ry="88" fill="rgba(57,255,20,0.85)" transform="rotate(-38,-5,110)"/><ellipse cx="225" cy="85" rx="17" ry="78" fill="rgba(0,200,16,0.75)" transform="rotate(42,225,85)"/><ellipse cx="110" cy="225" rx="16" ry="82" fill="rgba(57,255,20,0.85)" transform="rotate(16,110,225)"/><ellipse cx="35" cy="-5" rx="13" ry="70" fill="rgba(0,200,16,0.75)" transform="rotate(-22,35,-5)"/><ellipse cx="185" cy="220" rx="18" ry="80" fill="rgba(57,255,20,0.85)" transform="rotate(32,185,220)"/><circle cx="78" cy="68" r="15" fill="rgba(255,20,147,0.95)" opacity="0.95"/><circle cx="78" cy="68" r="5.5" fill="rgba(255,255,0,1)" opacity="0.97"/><circle cx="152" cy="152" r="13" fill="rgba(0,255,200,0.88)" opacity="0.9"/><circle cx="152" cy="152" r="5" fill="rgba(255,255,0,0.97)" opacity="0.97"/><circle cx="118" cy="28" r="8" fill="rgba(255,20,147,0.95)" opacity="0.85"/><circle cx="118" cy="28" r="3" fill="rgba(255,255,0,1)" opacity="0.95"/></svg>'; return 'background-color:#0a0a0a;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'tropical-pink': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><ellipse cx="-5" cy="110" rx="20" ry="88" fill="rgba(233,30,99,0.75)" transform="rotate(-38,-5,110)"/><ellipse cx="225" cy="85" rx="17" ry="78" fill="rgba(240,98,146,0.65)" transform="rotate(42,225,85)"/><ellipse cx="110" cy="225" rx="16" ry="82" fill="rgba(233,30,99,0.75)" transform="rotate(16,110,225)"/><ellipse cx="35" cy="-5" rx="13" ry="70" fill="rgba(240,98,146,0.65)" transform="rotate(-22,35,-5)"/><ellipse cx="185" cy="220" rx="18" ry="80" fill="rgba(233,30,99,0.75)" transform="rotate(32,185,220)"/><circle cx="78" cy="68" r="15" fill="rgba(255,128,171,0.92)" opacity="0.95"/><circle cx="78" cy="68" r="5.5" fill="rgba(255,210,0,0.97)" opacity="0.97"/><circle cx="118" cy="28" r="8" fill="rgba(255,128,171,0.92)" opacity="0.85"/><circle cx="118" cy="28" r="3" fill="rgba(255,210,0,0.97)" opacity="0.95"/></svg>'; return 'background-color:#fce4ec;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'tropical-sunset': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><ellipse cx="-5" cy="110" rx="20" ry="88" fill="rgba(74,0,128,0.75)" transform="rotate(-38,-5,110)"/><ellipse cx="225" cy="85" rx="17" ry="78" fill="rgba(109,40,217,0.65)" transform="rotate(42,225,85)"/><ellipse cx="110" cy="225" rx="16" ry="82" fill="rgba(74,0,128,0.75)" transform="rotate(16,110,225)"/><ellipse cx="35" cy="-5" rx="13" ry="70" fill="rgba(109,40,217,0.65)" transform="rotate(-22,35,-5)"/><ellipse cx="185" cy="220" rx="18" ry="80" fill="rgba(74,0,128,0.75)" transform="rotate(32,185,220)"/><circle cx="78" cy="68" r="15" fill="rgba(255,215,0,0.92)" opacity="0.95"/><circle cx="78" cy="68" r="5.5" fill="rgba(255,255,255,0.97)" opacity="0.97"/><circle cx="118" cy="28" r="8" fill="rgba(255,215,0,0.92)" opacity="0.85"/><circle cx="118" cy="28" r="3" fill="rgba(255,255,255,0.97)" opacity="0.95"/></svg>'; return 'background-color:#c2410c;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
        'tropical-dark': (() => { var s='<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220"><ellipse cx="-5" cy="110" rx="20" ry="88" fill="rgba(27,77,62,0.88)" transform="rotate(-38,-5,110)"/><ellipse cx="225" cy="85" rx="17" ry="78" fill="rgba(21,128,61,0.75)" transform="rotate(42,225,85)"/><ellipse cx="110" cy="225" rx="16" ry="82" fill="rgba(27,77,62,0.88)" transform="rotate(16,110,225)"/><ellipse cx="35" cy="-5" rx="13" ry="70" fill="rgba(21,128,61,0.75)" transform="rotate(-22,35,-5)"/><ellipse cx="185" cy="220" rx="18" ry="80" fill="rgba(27,77,62,0.88)" transform="rotate(32,185,220)"/><circle cx="78" cy="68" r="15" fill="rgba(212,175,55,0.92)" opacity="0.95"/><circle cx="78" cy="68" r="5.5" fill="rgba(255,235,100,0.97)" opacity="0.97"/><circle cx="118" cy="28" r="8" fill="rgba(212,175,55,0.92)" opacity="0.85"/><circle cx="118" cy="28" r="3" fill="rgba(255,235,100,0.97)" opacity="0.95"/></svg>'; return 'background-color:#0d1b2a;background-image:url("data:image/svg+xml,'+encodeURIComponent(s)+'");background-size:cover;'; })(),
    marble: `background: linear-gradient(
        105deg,
        ${color1} 0%,
        ${color2} 20%,
        ${adjustAlpha("#ffffff", 0.15)} 30%,
        ${color2} 40%,
        ${color1} 55%,
        ${adjustAlpha("#ffffff", 0.1)} 65%,
        ${color2} 75%,
        ${color1} 100%
      );`,
    carbon: `background-color: #1a1a1a;
      background-image:
        repeating-linear-gradient(
          45deg,
          transparent,
          transparent 2px,
          rgba(255,255,255,0.03) 2px,
          rgba(255,255,255,0.03) 4px
        ),
        repeating-linear-gradient(
          -45deg,
          transparent,
          transparent 2px,
          rgba(255,255,255,0.05) 2px,
          rgba(255,255,255,0.05) 4px
        );`,
    wood: `background: linear-gradient(
        170deg,
        #8B5E3C 0%,
        #A0714F 8%,
        #7a4f2d 16%,
        #9a6540 24%,
        #b07848 32%,
        #8a5c38 40%,
        #a06840 48%,
        #7c5030 56%,
        #9a6540 64%,
        #b27a4a 72%,
        #8c5e3a 80%,
        #a06840 88%,
        #7a4e2c 100%
      );`,

  };

  const headerBg = backgroundImage
    ? `background-image: url('${escHtml(backgroundImage)}'); background-size: cover; background-position: center; background-repeat: no-repeat;`
    : (patterns[pattern] || patterns.solid);



  return { headerBg, cardBg, cardBorder, textPri, textSec, pageBg, linkBg, linkBorder, linkColor, socBg, socBorder, socColor, cardRadius, darkMode, pattern, color1 };
}

function adjustAlpha(hex, alpha) {
  // Returns rgba from hex + alpha
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ── SOCIAL ICONS (SVG, no emojis) ────────────────────────────────────────────
function safeUrl(s) {
  var u = String(s || '').trim();
  if (/^javascript:/i.test(u) || /^data:/i.test(u) || /^vbscript:/i.test(u)) return '';
  if (u && !/^https?:\/\//i.test(u)) u = 'https://' + u;
  return u;
}

function normalizeSocialUrl(platform, val) {
  if (!val) return '';
  val = String(val).trim();
  if (!val) return '';
  // Full URL — use as-is
  if (/^https?:\/\//i.test(val)) return val;
  // Looks like a URL without protocol (e.g. "www.facebook.com/..." or "x.com/...") — prepend https://
  if (/^www\.|^(instagram|facebook|tiktok|youtube|linkedin|x|twitter|yelp|google)\./i.test(val)) return 'https://' + val;
  // Handle or username — strip leading @ and append to base
  const handle = val.replace(/^@/, '');
  const bases = {
    instagram: 'https://www.instagram.com/',
    tiktok:    'https://www.tiktok.com/@',
    twitter:   'https://x.com/',
    facebook:  'https://www.facebook.com/',
    youtube:   'https://www.youtube.com/',
    linkedin:  'https://www.linkedin.com/in/',
    yelp:      'https://www.yelp.com/biz/',
    google:    'https://www.google.com/maps/search/?q=',
    cashapp:   'https://cash.app/$',
    venmo:     'https://venmo.com/',
    paypal:    'https://paypal.me/',
  };
  return (bases[platform] || 'https://') + handle;
}

function getSocialIcon(platform) {
  const i = {
    instagram: ['#E1306C','<path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>'],
    facebook:  ['#1877F2','<path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>'],
    twitter:   ['#000000','<path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>'],
    tiktok:    ['#010101','<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34l.05-8.07a8.16 8.16 0 0 0 4.78 1.55V6.44a4.83 4.83 0 0 1-1.06-.25z"/>'],
    youtube:   ['#FF0000','<path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/>'],
    linkedin:  ['#0A66C2','<path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>'],
    yelp:      ['#D32323','<path d="M20.16 12.73l-4.703 1.612c-.8.276-1.464-.8-.887-1.494l3.085-3.7a.87.87 0 0 0-.105-1.24 9.204 9.204 0 0 0-2.742-1.566.877.877 0 0 0-1.108.52L12.16 12.9c-.294.832-1.53.832-1.824 0L8.3 6.854a.877.877 0 0 0-1.108-.52 9.204 9.204 0 0 0-2.742 1.566.87.87 0 0 0-.105 1.24l3.085 3.7c.577.694-.087 1.77-.887 1.494L1.84 12.73a.877.877 0 0 0-1.107.72 9.277 9.277 0 0 0 .386 3.163.877.877 0 0 0 1.023.58l4.86-1.07c.826-.182 1.358.886.78 1.504l-3.25 3.455a.877.877 0 0 0 .064 1.249 9.22 9.22 0 0 0 2.913 1.738.877.877 0 0 0 1.085-.47l1.985-4.527c.338-.77 1.462-.77 1.8 0l1.985 4.527a.877.877 0 0 0 1.085.47 9.22 9.22 0 0 0 2.913-1.738.877.877 0 0 0 .064-1.249l-3.25-3.455c-.578-.618-.046-1.686.78-1.504l4.86 1.07a.877.877 0 0 0 1.023-.58 9.277 9.277 0 0 0 .386-3.162.877.877 0 0 0-1.107-.72z"/>'],
    cashapp:   ['#00D54B','<path d="M17.15 8.37c-.15-.67-.5-1.24-1-1.66A3.27 3.27 0 0 0 14.06 7.72H8.5a.77.77 0 0 0-.76.76v9.44c0 .42.34.76.76.76h5.56c.81 0 1.52-.27 2.09-.76.5-.44.85-1.06.97-1.78.08-.43.05-.84-.06-1.22a2.6 2.6 0 0 0-.63-1.07 2.57 2.57 0 0 0 .66-1.12c.1-.37.11-.77.06-1.16zm-7.15-.35h3.76c.38 0 .69.1.91.28.2.17.32.42.36.73.04.3-.01.56-.14.76a.88.88 0 0 1-.77.4H10V8.02zm4.08 5.63c-.22.19-.52.3-.9.3H10v-2.3h3.18c.38 0 .67.1.89.28.2.17.32.42.36.74.03.3-.02.56-.15.76z" fill="white"/>'],
    venmo:     ['#008CFF','<path d="M19.02 1.6c.5.82.72 1.67.72 2.76 0 3.44-2.94 7.9-5.33 11.04H9.28L6.97 2.46l4.67-.44 1.2 9.54c1.13-1.84 2.5-4.74 2.5-6.72 0-1.08-.18-1.82-.46-2.42z" fill="white"/>'],
    paypal:    ['#009CDE','<text x="3" y="17" font-size="12" font-weight="900" fill="white" font-family="Arial">P</text>'],
    zelle:     ['#6D1ED4','<path d="M15.6 4H8.4L4 12l4.4 8h7.2L20 12zm-1.45 11.5H9.6l3.4-6.2H9.15l.75-1.3h5.1l-3.4 6.2h3.85z" fill="white"/>'],
    booking:   ['#0f6b6b','<rect x="3" y="4" width="18" height="18" rx="2" ry="2" stroke="white" stroke-width="2" fill="none"/><line x1="16" y1="2" x2="16" y2="6" stroke="white" stroke-width="2"/><line x1="8" y1="2" x2="8" y2="6" stroke="white" stroke-width="2"/><line x1="3" y1="10" x2="21" y2="10" stroke="white" stroke-width="2"/>'],
    menu:      ['#f4752b','<line x1="3" y1="6" x2="21" y2="6" stroke="white" stroke-width="2.5" stroke-linecap="round"/><line x1="3" y1="12" x2="21" y2="12" stroke="white" stroke-width="2.5" stroke-linecap="round"/><line x1="3" y1="18" x2="21" y2="18" stroke="white" stroke-width="2.5" stroke-linecap="round"/>'],
    google:    ['#ffffff','<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>'],
  };
  const d = i[platform];
  if (!d) return `<svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`;
  const [bg, path] = d;
  return `<span class="soc-badge" style="background:${bg}"><svg viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">${path}</svg></span>`;
}

// ── HTML RENDERER ──────────────────────────────────────────────────────────────

function renderProfile(p, reviews = [], photos = [], documents = []) {
  const theme    = (typeof p.theme === "object" && p.theme) ? p.theme : {};
  const t        = getThemeCSS(theme, p.background_image || null);
  const links    = Array.isArray(p.links)   ? p.links   : [];
  const contentBlocks  = Array.isArray(p.content_blocks) ? p.content_blocks : [];
  const updateBlocks   = contentBlocks.filter(b => b.type === 'update');
  const menuBlocks     = contentBlocks.filter(b => b.type === 'menu');
  const serviceBlocks  = contentBlocks.filter(b => b.type === 'service');
  const socials  = p.socials || {};
  const sections = theme.sections || {};

  // Section visibility defaults (true = show)
  const showLinks   = sections.links   !== false;
  const showSocials = sections.socials !== false;
  const showVideo   = sections.video   !== false;
  const showLead    = sections.lead    !== false;
  const showBio     = sections.bio     !== false;

  // ── HERO LAYOUT ─────────────────────────────────────────────────────────────
  // photoLayout: 'logo' | 'headshot' | 'both' | 'auto' (default)
  const photoLayout = theme.photoLayout || 'auto';
  let eff = photoLayout;
  if (eff === 'auto') {
    eff = (p.logo_url && p.photo_url) ? 'both' : p.photo_url ? 'headshot' : 'logo';
  }

  let heroPhotos = '';
  if (eff === 'both' && p.logo_url && p.photo_url) {
    heroPhotos = `<div class="hero-duo">
      <div class="duo-item">
        <div class="avatar-lg"><img src="${escHtml(p.logo_url)}" alt="${escHtml(p.business_name||"")}" loading="eager" fetchpriority="high" onerror="this.style.display='none'"/></div>
        ${p.business_name ? `<p class="duo-caption">${escHtml(p.business_name)}</p>` : ""}
      </div>
      <div class="duo-item">
        <div class="avatar-lg person"><img src="${escHtml(p.photo_url)}" alt="${escHtml(p.owner_name||"")}" loading="eager" fetchpriority="high" onerror="this.style.display='none'"/></div>
        ${p.owner_name ? `<p class="duo-caption">${escHtml(p.owner_name)}</p>` : ""}
      </div>
    </div>`;
  } else if (eff === 'headshot' && p.photo_url) {
    heroPhotos = `<div class="hero-solo"><div class="avatar-xl person"><img src="${escHtml(p.photo_url)}" alt="${escHtml(p.owner_name||p.business_name||"")}" loading="eager" fetchpriority="high" onerror="this.style.display='none'"/></div></div>`;
  } else if (p.logo_url) {
    heroPhotos = `<div class="hero-solo"><div class="avatar-xl"><img src="${escHtml(p.logo_url)}" alt="${escHtml(p.business_name||"")}" loading="eager" fetchpriority="high" onerror="this.style.display='none'"/></div></div>`;
  } else {
    heroPhotos = `<div class="hero-solo"><div class="avatar-xl"><span style="font-size:3rem;">🏢</span></div></div>`;
  }

  // ── LINKS ───────────────────────────────────────────────────────────────────
  const customLinks = showLinks ? links
    .filter(l => l.label && l.url)
    .map(l => `<a href="${escHtml(safeUrl(l.url))}" target="_blank" rel="noopener" class="link-btn">
      <span class="link-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></span>
      <span class="link-label-text">${escHtml(l.label)}</span>
    </a>`).join("") : "";

  // ── SOCIALS ─────────────────────────────────────────────────────────────────
  const socialLabels = {
    instagram: "Instagram", facebook: "Facebook", twitter: "Twitter / X",
    tiktok: "TikTok", youtube: "YouTube", linkedin: "LinkedIn",
    yelp: "Yelp", google: "Google Business",
  };

  const _socialOnly = ['instagram','facebook','tiktok','youtube','linkedin','twitter','yelp','google'];
  const socialLinks = showSocials ? Object.entries(socials)
    .filter(([k, url]) => url && _socialOnly.includes(k))
    .map(([platform, url]) => {
      const label = socialLabels[platform] || platform;
      const href = normalizeSocialUrl(platform, url);
      return `<a href="${escHtml(href)}" target="_blank" rel="noopener" class="social-btn">
        ${getSocialIcon(platform)}
        <span class="soc-name">${label}</span>
      </a>`;
    }).join("") : "";

  // PAYMENTS
  const _payMap = {cashapp:'Pay via Cash App',venmo:'Pay via Venmo',paypal:'Pay via PayPal',zelle:'Pay via Zelle'};
  const paymentButtons = ['cashapp','venmo','paypal','zelle'].filter(k => socials[k]).map(platform => {
    const val = String(socials[platform]||'').trim();
    if (platform === 'zelle') {
      const zId = escHtml(val); const zJs = escJs(val);
      return '<button type="button" class="payment-btn" onclick="(function(b){var t=document.createElement(\'textarea\');t.value=\'' + zJs + '\';document.body.appendChild(t);t.select();try{document.execCommand(\'copy\');}catch(e){}document.body.removeChild(t);var l=b.querySelector(\'.pay-lbl\');var o=l.textContent;l.textContent=\'Copied!\';setTimeout(function(){l.textContent=o;},2000);})(this)">' +
        getSocialIcon('zelle') +
        '<span class="pay-content"><span class="pay-lbl">' + _payMap[platform] + '</span><span class="pay-id">' + zId + '</span></span></button>';
    }
    const href = normalizeSocialUrl(platform, val);
    return '<a href="' + escHtml(href) + '" target="_blank" rel="noopener" class="payment-btn">' +
      getSocialIcon(platform) +
      '<span class="pay-content"><span class="pay-lbl">' + _payMap[platform] + '</span></span></a>';
  }).join('');
  const paymentsSection = paymentButtons
    ? '<div class="card"><div class="section-title">Pay</div><div class="payments-wrap">' + paymentButtons + '</div></div>'
    : '';

  // BOOKING + MENU
  const _bUrl = socials.booking ? safeUrl(String(socials.booking)) : '';
  const bookingBtn = _bUrl
    ? '<a href="' + escHtml(_bUrl) + '" target="_blank" rel="noopener" class="cta-link-btn booking-cta">' + getSocialIcon('booking') + '<span>Book an Appointment</span></a>'
    : '';
  const _mUrl = socials.menu ? safeUrl(String(socials.menu)) : '';
  const menuBtn = _mUrl
    ? '<a href="' + escHtml(_mUrl) + '" target="_blank" rel="noopener" class="cta-link-btn menu-cta">' + getSocialIcon('menu') + '<span>View Menu</span></a>'
    : '';

  // ── VIDEO ───────────────────────────────────────────────────────────────────
  const _embedUrl   = p.video_url ? toEmbedUrl(p.video_url) : "";
  const videoEmbed = (showVideo && _embedUrl)
    ? `<div class="card"><div class="section-title">Intro</div>
        <div class="video-wrap">
          <iframe src="${escHtml(_embedUrl)}" frameborder="0" allowfullscreen
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            loading="lazy"></iframe>
        </div>
       </div>` : "";

  // ── BIO ─────────────────────────────────────────────────────────────────────
  const bioSection = (showBio && p.bio)
    ? `<div class="card"><div class="section-title">About</div>
        <p class="bio-text">${escHtml(p.bio)}</p>
       </div>` : "";

  // ── PHONE ───────────────────────────────────────────────────────────────────
  const phoneSection = p.phone
    ? `<a href="tel:${escHtml(p.phone)}" class="link-btn phone-btn">
        <span class="link-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12.7 19.79 19.79 0 0 1 1.61 4.1 2 2 0 0 1 3.59 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.18 6.18l1.27-.92a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></span>
        <span class="link-label-text">${escHtml(p.phone)}</span>
       </a>` : "";

  // ── LEAD FORM ────────────────────────────────────────────────────────────────
  const leadSection = (showLead && p.lead_form_enabled) ? buildLeadForm(p) : "";

  // ── Photo gallery ─────────────────────────────────────────────────
  var gallerySection = '';
  if (photos && photos.length > 0) {
    var thumbsHtml = photos.map(function(ph) {
      var cap = ph.caption ? '<div class="thumb-caption">' + escHtml(ph.caption) + '</div>' : '';
      return '<div class="gallery-thumb" data-id="' + escHtml(ph.id) + '" data-url="' + escHtml(ph.file_url) + '" data-caption="' + escHtml(ph.caption||'') + '" onclick="openLightbox(\'' + escJs(ph.id) + '\',\'' + escJs(ph.file_url) + '\',\'' + escJs(ph.caption||'') + '\')">' +
        '<img src="' + escHtml(ph.file_url) + '" alt="' + escHtml(ph.caption||'Gallery photo') + '" loading="lazy" onerror="this.onerror=null;this.hidden=true" />' +
        cap + '</div>';
    }).join('');
    gallerySection = '<section class="section-gallery">' +
      '<p class="section-media-heading" style="color:' + t.textPri + ';">Gallery</p>' +
      '<div class="gallery-grid">' + thumbsHtml + '</div></section>';
  }

  // ── Documents ─────────────────────────────────────────────────────
  var documentsSection = '';
  if (documents && documents.length > 0) {
    var docCards = documents.map(function(d) {
      var icon = d.file_type === 'pdf' ? '\u{1F4C4}' : '\u{1F4DD}';
      return '<a href="' + escHtml(d.file_url) + '" target="_blank" rel="noopener" class="doc-card" style="background:' + t.cardBg + ';border:1px solid ' + t.cardBorder + ';">' +
        '<span class="doc-icon-wrap">' + (d.file_type === 'pdf' ? '📄' : '📝') + '</span>' +
        '<span class="doc-label" style="color:' + t.textPri + ';">' + escHtml(d.title) + '</span>' +
        '<span class="doc-arrow" style="color:' + t.textSec + ';">&#8599;</span>' +
        '</a>';
    }).join('');
    documentsSection = '<section class="section-documents">' +
      '<p class="section-media-heading" style="color:' + t.textPri + ';">Documents &amp; Flyers</p>' +
      docCards + '</section>';
  }

  // ── AMERICA CANTON ───────────────────────────────────────────────────────────
  // ── CONTENT BLOCKS ────────────────────────────────────────────────────────
  const updatesSection = updateBlocks.length ? `
  <div class="card">
    <div class="section-title">Updates &amp; Specials</div>
    ${updateBlocks.map(b => `
      <div class="update-card">
        <div class="update-badge">📢 Update</div>
        ${b.title ? `<div class="update-title">${escHtml(b.title)}</div>` : ""}
        ${b.text  ? `<div class="update-text">${escHtml(b.text)}</div>` : ""}
      </div>
    `).join("")}
  </div>` : "";

  const menuByCategory = {};
  menuBlocks.forEach(b => {
    const cat = b.category || "Menu";
    if (!menuByCategory[cat]) menuByCategory[cat] = [];
    menuByCategory[cat].push(b);
  });
  const menuSection = menuBlocks.length ? `
  <div class="card">
    <div class="section-title">Menu</div>
    ${Object.entries(menuByCategory).map(([cat, items]) => `
      <div class="menu-cat-label">${escHtml(cat)}</div>
      ${items.map(b => `
        <div class="menu-row">
          <div class="menu-item-left">
            <div class="menu-item-name">${escHtml(b.name || "")}</div>
            ${b.description ? `<div class="menu-item-desc">${escHtml(b.description)}</div>` : ""}
          </div>
          ${b.price ? `<div class="menu-item-price">${escHtml(b.price)}</div>` : ""}
        </div>
      `).join("")}
    `).join("")}
  </div>` : "";

  const servicesSection = serviceBlocks.length ? `
  <div class="card">
    <div class="section-title">Services</div>
    ${serviceBlocks.map(b => `
      <div class="service-row">
        <div class="service-left">
          <div class="service-name">${escHtml(b.name || "")}</div>
          ${b.description ? `<div class="service-desc">${escHtml(b.description)}</div>` : ""}
        </div>
        ${b.price ? `<div class="service-price">${escHtml(b.price)}</div>` : ""}
      </div>
    `).join("")}
  </div>` : "";

  const stars50 = Array(50).fill("★").join(" ");
  // ── LocalBusiness JSON-LD ────────────────────────────────────────────
  const _socialEntries = Object.entries(p.socials || {}).filter(([, v]) => v);
  const _ratingReviews = (reviews || []).filter(r => r.rating);
  const _ratingCount   = _ratingReviews.length;
  const _ratingAvg     = _ratingCount > 0
    ? (_ratingReviews.reduce((s, r) => s + r.rating, 0) / _ratingCount).toFixed(1)
    : null;
  // Include up to 5 most-recent visible reviews with text in JSON-LD for rich snippets
  const _reviewsForLd = (reviews || [])
    .filter(r => r.reviewer_name && r.review_text)
    .slice(0, 5)
    .map(r => ({
      "@type":        "Review",
      "author":       { "@type": "Person", "name": r.reviewer_name },
      "reviewBody":   r.review_text,
      ...(r.rating ? { "reviewRating": { "@type": "Rating", "ratingValue": r.rating, "bestRating": 5 } } : {}),
      ...(r.submitted_at ? { "datePublished": r.submitted_at.slice(0, 10) } : {}),
    }));
  const jsonLd = JSON.stringify({
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": p.business_name || "",
    "url": "https://torrolink.com/p/" + (p.handle || ""),
    ...(p.tagline || p.bio ? { "description": (p.tagline || (p.bio || "").slice(0, 200)) } : {}),
    ...(p.phone    ? { "telephone": p.phone }   : {}),
    ...(p.logo_url ? { "image": p.logo_url }    : {}),
    ...(_ratingAvg ? { "aggregateRating": { "@type": "AggregateRating", "ratingValue": _ratingAvg, "reviewCount": _ratingCount } } : {}),
    ...(_reviewsForLd.length ? { "review": _reviewsForLd } : {}),
    "sameAs": _socialEntries.map(([k, v]) => normalizeSocialUrl(k, v)).filter(Boolean),
  });

  return `<!DOCTYPE html>
<html lang="en"${t.darkMode ? ' class="dark"' : ""}>
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escHtml(p.business_name || "Business Profile")} — Torrolink</title>
  <meta name="description" content="${escHtml(p.tagline || p.bio || p.business_name || "")}" />
  <meta name="robots" content="index, follow" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="Torrolink" />
  <meta property="og:title" content="${escHtml(p.business_name || "")}" />
  <meta property="og:description" content="${escHtml(p.tagline || p.bio?.slice(0,160) || "")}" />
  <meta property="og:url" content="https://torrolink.com/p/${escHtml(p.handle || "")}" />
  ${p.logo_url ? `<meta property="og:image" content="${escHtml(p.logo_url)}" />
  <meta property="og:image:width" content="400" />
  <meta property="og:image:height" content="400" />` : ""}
  <meta name="twitter:card" content="summary" />
  <meta name="twitter:title" content="${escHtml(p.business_name || "")}" />
  <meta name="twitter:description" content="${escHtml(p.tagline || p.bio?.slice(0,160) || "")}" />
  ${p.logo_url ? `<meta name="twitter:image" content="${escHtml(p.logo_url)}" />` : ""}
  <link rel="canonical" href="https://torrolink.com/p/${escHtml(p.handle || "")}" />
  <script type="application/ld+json">${jsonLd}</script>
  <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
  <meta name="theme-color" content="${t.color1 || '#0f6b6b'}" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', sans-serif;
      background: ${t.pageBg};
      color: ${t.textPri};
      min-height: 100vh;
      transition: background 0.3s;
    }

    /* ── HEADER ─────────────────────────────────── */
    .hero-band {
      ${t.headerBg}
      padding: 48px 24px 90px;
      text-align: center;
      position: relative;
      overflow: hidden;
      min-height: 290px;
    }
    /* America canton */
    .star-canton {
      position: absolute; top: 0; left: 0;
      width: 38%; max-width: 155px;
      height: 54%;
      background: #3C3B6E;
    }
    .star-canton svg { display: block; width: 100%; height: 100%; }

    /* ── HERO PHOTOS ─────────────────────────────── */
    .hero-solo { display: flex; justify-content: center; margin: 0 auto 20px; }
    .avatar-xl {
      width: 152px; height: 152px; border-radius: 50%;
      overflow: hidden; flex-shrink: 0;
      border: 5px solid rgba(255,255,255,0.55);
      box-shadow: 0 0 0 3px rgba(255,255,255,0.15), 0 16px 48px rgba(0,0,0,0.35);
      background: rgba(255,255,255,0.12);
      display: flex; align-items: center; justify-content: center;
    }
    .avatar-xl.person { border-color: rgba(255,255,255,0.75); }
    .avatar-xl img { width: 100%; height: 100%; object-fit: cover; }
    .hero-duo { display: flex; gap: 28px; justify-content: center; margin: 0 auto 20px; }
    .duo-item { text-align: center; }
    .avatar-lg {
      width: 122px; height: 122px; border-radius: 50%;
      overflow: hidden; margin: 0 auto;
      border: 4px solid rgba(255,255,255,0.55);
      box-shadow: 0 0 0 2px rgba(255,255,255,0.12), 0 10px 32px rgba(0,0,0,0.3);
      background: rgba(255,255,255,0.12);
      display: flex; align-items: center; justify-content: center;
    }
    .avatar-lg.person { border-color: rgba(255,255,255,0.75); }
    .avatar-lg img { width: 100%; height: 100%; object-fit: cover; }
    .duo-caption {
      font-size: 0.72rem; font-weight: 600; letter-spacing: 0.02em;
      color: rgba(255,255,255,0.82); margin-top: 7px;
      text-shadow: 0 1px 4px rgba(0,0,0,0.4);
    }
    .dot {
      width: 7px; height: 7px; border-radius: 50%;
      background: rgba(255,255,255,0.4); border: none; cursor: pointer;
      padding: 0; transition: background 0.2s;
    }
    .dot.active { background: #fff; }

    .biz-name {
      font-size: 1.75rem; font-weight: 800;
      color: #fff; line-height: 1.2; margin-bottom: 8px;
      text-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .tagline {
      font-size: 1rem; color: rgba(255,255,255,0.85);
      line-height: 1.5;
      text-shadow: 0 1px 4px rgba(0,0,0,0.25);
    }
    /* Carbon/wood — always light text */
    .hero-band.dark-header .biz-name,
    .hero-band.dark-header .tagline,
    .hero-band.dark-header .slide-label { color: #f0f0f0; }

    /* ── CARDS ───────────────────────────────────── */
    .card {
      background: ${t.cardBg};
      border-radius: ${t.cardRadius};
      box-shadow: 0 4px 24px rgba(0,0,0,${t.darkMode ? "0.3" : "0.08"});
      margin: -40px auto 20px;
      max-width: 480px;
      padding: 28px 24px;
      position: relative;
      border: 1px solid ${t.cardBorder};
    }
    .card + .card { margin-top: 0; }

    .section-title {
      font-size: 0.72rem; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.08em;
      color: ${t.textSec};
      margin-bottom: 14px;
    }

    /* ── BUTTONS ─────────────────────────────────── */
    .link-btn, .social-btn {
      display: flex; align-items: center; gap: 10px;
      width: 100%; padding: 14px 18px;
      border-radius: 12px;
      text-decoration: none;
      font-size: 0.95rem; font-weight: 600;
      margin-bottom: 10px;
      transition: transform 0.15s, box-shadow 0.15s, opacity 0.15s;
      color: ${t.linkColor};
      background: ${t.linkBg};
      border: 1px solid ${t.linkBorder};
    }
    .payments-wrap { display: flex; flex-direction: column; gap: 10px; }
    .payment-btn {
      display: flex; align-items: center; gap: 12px;
      padding: 12px 16px; border-radius: 12px; width: 100%; box-sizing: border-box;
      text-decoration: none; font-size: 0.88rem; font-weight: 600;
      border: 1.5px solid rgba(0,0,0,0.1); background: #fff;
      cursor: pointer; font-family: inherit; transition: opacity 0.15s; color: #1a1a1a;
    }
    .payment-btn:hover { opacity: 0.82; }
    .payment-btn .soc-badge { width: 36px; height: 36px; flex-shrink: 0; border-radius: 8px; }
    .payment-btn .soc-badge svg { width: 20px; height: 20px; }
    .pay-content { display: flex; flex-direction: column; text-align: left; }
    .pay-lbl { font-weight: 600; font-size: 0.88rem; }
    .pay-id { font-size: 0.76rem; color: #666; margin-top: 2px; }
    .cta-link-btn {
      display: flex; align-items: center; gap: 10px;
      padding: 13px 16px; border-radius: 12px; width: 100%; box-sizing: border-box;
      text-decoration: none; font-size: 0.92rem; font-weight: 700;
      margin-top: 10px; color: #fff; transition: opacity 0.15s;
    }
    .cta-link-btn:hover { opacity: 0.85; }
    .booking-cta { background: #0f6b6b; }
    .menu-cta { background: #f4752b; }
    .cta-link-btn .soc-badge { background: rgba(255,255,255,0.22) !important; width: 32px; height: 32px; border-radius: 8px; }
    .cta-link-btn .soc-badge svg { width: 18px; height: 18px; }
    .social-btn {
      color: ${t.socColor};
      background: ${t.socBg};
      border-color: ${t.socBorder};
    }
    .link-btn:hover, .social-btn:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 14px rgba(0,0,0,${t.darkMode ? "0.3" : "0.1"});
    }
    .phone-btn { color: ${t.linkColor}; background: ${t.linkBg}; border-color: ${t.linkBorder}; }
    .link-icon {
      width: 36px; height: 36px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      border-radius: 8px;
      background: rgba(15,107,107,0.12);
      color: #0f6b6b;
    }
    .link-icon svg { width: 18px; height: 18px; }
    .link-label-text { flex: 1; }
    .soc-badge {
      width: 38px; height: 38px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      border-radius: 10px;
    }
    .soc-badge svg { width: 20px; height: 20px; }
    .soc-name { flex: 1; font-weight: 600; }

    /* ── BIO ─────────────────────────────────────── */
    .bio-text {
      font-size: 0.95rem; color: ${t.textSec};
      line-height: 1.75; white-space: pre-wrap;
    }

    /* ── VIDEO ───────────────────────────────────── */
    .video-wrap {
      position: relative; padding-bottom: 56.25%;
      height: 0; border-radius: 12px; overflow: hidden;
    }
    .video-wrap iframe {
      position: absolute; top: 0; left: 0;
      width: 100%; height: 100%;
    }

    /* ── LEAD FORM ───────────────────────────────── */
    .lead-form input, .lead-form textarea {
      width: 100%; padding: 12px 14px;
      border: 1.5px solid ${t.cardBorder};
      border-radius: 10px;
      font-size: 0.95rem; font-family: inherit;
      margin-bottom: 10px; outline: none;
      background: ${t.darkMode ? "#12121f" : "#fafafa"};
      color: ${t.textPri};
      transition: border-color 0.2s;
    }
    .lead-form input:focus, .lead-form textarea:focus { border-color: #0f6b6b; }
    .check-label {
      display: flex; align-items: center; gap: 8px;
      font-size: 0.9rem; color: ${t.textSec};
      margin-bottom: 8px; cursor: pointer;
    }
    .check-label input { width: auto; margin: 0; accent-color: #0f6b6b; }
    .checkboxes { margin-bottom: 12px; }
    .submit-btn {
      width: 100%; padding: 14px;
      background: #0f6b6b; color: #fff;
      border: none; border-radius: 12px;
      font-size: 1rem; font-weight: 700;
      cursor: pointer; font-family: inherit;
      transition: background 0.2s, transform 0.15s;
    }
    .submit-btn:hover { background: #0a4a4a; transform: translateY(-1px); }
    .submit-btn:disabled { background: #aaa; cursor: default; transform: none; }
    .form-success {
      text-align: center; padding: 24px;
      color: #0f6b6b; font-weight: 600;
      font-size: 1rem; display: none;
    }

    /* ── HOLIDAY BADGE ───────────────────────────── */
    .holiday-badge {
      display: inline-block;
      background: rgba(255,255,255,0.2);
      color: #fff; font-size: 0.75rem; font-weight: 700;
      padding: 4px 12px; border-radius: 20px;
      margin-bottom: 12px;
      border: 1px solid rgba(255,255,255,0.3);
    }

    /* ── UPDATES / SPECIALS ──────────────────────── */
    .update-card {
      border-left: 4px solid #f4752b;
      border-radius: 0 12px 12px 0;
      padding: 14px 16px;
      margin-bottom: 12px;
    }
    .update-badge {
      display: inline-block; font-size: 0.68rem; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.07em;
      color: #fff; background: #f4752b;
      border-radius: 20px; padding: 2px 9px; margin-bottom: 6px;
    }
    .update-title { font-weight: 700; font-size: 0.96rem; margin-bottom: 4px; }
    .update-text  { font-size: 0.88rem; line-height: 1.6; }

    /* ── MENU ──────────────────────────────────────────────── */
    .menu-cat-label {
      font-size: 0.7rem; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.1em; color: #8b5cf6; margin: 16px 0 8px;
      padding-bottom: 4px; border-bottom: 1px solid rgba(139,92,246,0.18);
    }
    .menu-cat-label:first-child { margin-top: 0; }
    .menu-row {
      display: flex; justify-content: space-between; align-items: flex-start;
      padding: 9px 0; gap: 12px;
    }
    .menu-row + .menu-row { border-top: 1px dashed rgba(0,0,0,0.07); }
    .menu-item-left { flex: 1; }
    .menu-item-name { font-weight: 600; font-size: 0.93rem; }
    .menu-item-desc { font-size: 0.8rem; margin-top: 2px; opacity: 0.72; line-height: 1.45; }
    .menu-item-price { font-weight: 700; font-size: 0.93rem; color: #0f6b6b; white-space: nowrap; }

    /* ── SERVICES ──────────────────────────────────────────── */
    .service-row {
      display: flex; justify-content: space-between; align-items: flex-start;
      padding: 11px 0; gap: 12px;
    }
    .service-row + .service-row { border-top: 1px dashed rgba(0,0,0,0.07); }
    .service-left { flex: 1; }
    .service-name { font-weight: 700; font-size: 0.93rem; }
    .service-desc { font-size: 0.8rem; margin-top: 2px; opacity: 0.72; line-height: 1.45; }
    .service-price { font-weight: 700; color: #0f6b6b; white-space: nowrap; font-size: 0.93rem; }

    /* ── REVIEWS ────────────────────────────────────────────── */
    .review-card {
      border-radius: 12px; padding: 14px 16px; margin-bottom: 10px;
      background: rgba(15,107,107,0.04);
    }
    .review-card.featured { background: rgba(244,167,36,0.06); }
    .featured-badge {
      display: inline-block; font-size: 0.7rem; font-weight: 700;
      color: #92400e; background: #fef3c7; border-radius: 20px;
      padding: 2px 9px; margin-bottom: 6px;
    }
    .review-stars { font-size: 1.05rem; color: #f4a724; letter-spacing: 1px; margin-bottom: 5px; }
    .review-text { font-size: 0.9rem; line-height: 1.65; margin-bottom: 7px; font-style: italic; opacity: 0.88; }
    .review-author { font-size: 0.82rem; font-weight: 600; }
    .review-write-btn {
      width: 100%; padding: 12px; margin-top: 10px;
      background: transparent; cursor: pointer;
      font-size: 0.9rem; font-family: inherit; font-weight: 600;
      transition: all 0.2s; border-radius: 12px;
      border: 1.5px dashed rgba(15,107,107,0.3); color: #0f6b6b;
    }
    .review-write-btn:hover { border-color: #0f6b6b; background: rgba(15,107,107,0.05); }
    .star-picker { display: flex; gap: 6px; margin-bottom: 12px; }
    .star-btn {
      background: none; border: none; font-size: 1.8rem; cursor: pointer;
      color: #ddd; padding: 0; transition: color 0.12s; line-height: 1;
    }
    .star-btn.on { color: #f4a724; }
    .review-input {
      width: 100%; padding: 11px 14px; border-radius: 10px;
      font-size: 0.92rem; font-family: inherit;
      margin-bottom: 10px; outline: none; resize: vertical;
      border: 1.5px solid rgba(0,0,0,0.14);
      background: transparent; color: inherit;
      transition: border-color 0.2s;
    }
    .review-input:focus { border-color: #0f6b6b; }
    .review-avg-bar {
      display: flex; align-items: center; gap: 14px;
      padding: 12px 14px; border-radius: 12px; margin-bottom: 14px;
      background: rgba(244,167,36,0.07); border: 1px solid rgba(244,167,36,0.18);
    }
    .review-avg-score { font-size: 2rem; font-weight: 800; color: #92400e; line-height: 1; }
    .review-avg-stars { font-size: 1.1rem; color: #f4a724; letter-spacing: 1px; }
    .review-avg-label { font-size: 0.78rem; opacity: 0.62; margin-top: 2px; }

    /* ── FOOTER ──────────────────────────────────── */
    /* Entrance animations */
    @keyframes fadeUp { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: none; } }
    .card, .section-gallery, .section-documents { animation: fadeUp 0.42s ease both; }
    .card:nth-child(2) { animation-delay: 0.06s; }
    .card:nth-child(3) { animation-delay: 0.12s; }
    .card:nth-child(4) { animation-delay: 0.18s; }
    .card:nth-child(5) { animation-delay: 0.24s; }
    .section-gallery   { animation-delay: 0.2s; }
    .section-documents { animation-delay: 0.26s; }

    /* Share + vCard bar */
    .profile-action-bar {
      display: flex; justify-content: center; gap: 10px;
      padding: 14px 16px 0; flex-wrap: wrap;
    }
    .action-btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 8px 18px; border-radius: 50px;
      font-size: 0.82rem; font-weight: 600; cursor: pointer;
      border: 1.5px solid ${t.cardBorder}; background: ${t.cardBg};
      color: ${t.textPri}; text-decoration: none; transition: opacity 0.15s, transform 0.12s;
    }
    .action-btn:hover { opacity: 0.82; transform: scale(1.03); }
    .action-btn.share-btn { border-color: #0f6b6b; color: #0f6b6b; }

    /* Powered by */
    .powered {
      text-align: center; padding: 20px 24px 44px;
      font-size: 0.8rem; color: ${t.textSec};
    }
    .powered a { color: #0f6b6b; text-decoration: none; font-weight: 600; }
    .powered .get-yours { display: block; margin-top: 6px; font-size: 0.78rem; }
    .powered .get-yours a { background: #0f6b6b; color: #fff; padding: 5px 14px; border-radius: 20px; font-weight: 700; }

    /* QR share overlay */
    .qr-overlay {
      display: none; position: fixed; inset: 0; z-index: 9999;
      background: rgba(0,0,0,0.88); align-items: center; justify-content: center;
      flex-direction: column; cursor: pointer;
    }
    .qr-overlay.open { display: flex; }
    .qr-overlay-box {
      background: #fff; border-radius: 20px; padding: 28px 24px 20px;
      text-align: center; max-width: 320px; width: 90%; cursor: default;
    }
    .qr-overlay-box img { width: 240px; height: 240px; border-radius: 8px; display: block; margin: 0 auto; }
    .qr-overlay-url { margin: 12px 0 4px; font-size: 0.82rem; color: #333; font-weight: 600; }
    .qr-overlay-hint { font-size: 0.7rem; color: #aaa; margin-top: 2px; }
    .qr-overlay-close {
      position: absolute; top: 18px; right: 22px; background: none; border: none;
      color: #fff; font-size: 2rem; cursor: pointer; line-height: 1;
    }

    /* TorroLink CTA bottom block */
    .tl-cta-bottom {
      text-align: center; padding: 22px 20px 48px;
      border-top: 1px solid rgba(128,128,128,0.12); margin-top: 4px;
    }
    .tl-cta-powered { font-size: 0.78rem; color: #aaa; margin-bottom: 14px; }
    .tl-cta-powered a { color: #0f6b6b; text-decoration: none; font-weight: 600; }
    .tl-cta-btns { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
    .tl-cta-btns a {
      display: inline-block; padding: 10px 20px; border-radius: 50px;
      font-size: 0.83rem; font-weight: 700; text-decoration: none;
      transition: opacity 0.15s, transform 0.12s;
    }
    .tl-cta-btns a:hover { opacity: 0.82; transform: scale(1.03); }
    .tl-cta-btn-primary { background: #0f6b6b; color: #fff !important; }
    .tl-cta-btn-ghost { border: 2px solid #0f6b6b; color: #0f6b6b !important; background: transparent; }

    /* ── MOBILE ──────────────────────────────────── */
    @media (max-width: 520px) {
      .hero-band { padding: 40px 20px 80px; min-height: 260px; }
      .card { margin: -40px 16px 16px; padding: 18px; }
      .biz-name { font-size: 1.55rem; }
      .tagline { font-size: 0.88rem; }
      .hero-duo { gap: 18px; }
      .avatar-xl { width: 120px; height: 120px; }
      .avatar-lg { width: 100px; height: 100px; }
      .section-title { font-size: 0.78rem; }
      .link-row { padding: 11px 14px; font-size: 0.9rem; }
      .social-grid { grid-template-columns: repeat(4, 1fr); }
      .gallery-grid { grid-template-columns: repeat(2, 1fr); gap: 5px; }
      .profile-action-bar { gap: 8px; }
      .action-btn { font-size: 0.78rem; padding: 7px 14px; }
    }
    /* ── Gallery & Documents ───────────────────────────────── */
    .section-gallery { padding: 20px 16px 8px; }
    .section-documents { padding: 8px 16px 20px; }
    .section-media-heading { font-size: 1rem; font-weight: 700; margin: 0 0 12px; }
    .gallery-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
    .gallery-thumb { position: relative; cursor: pointer; border-radius: 8px; overflow: hidden; aspect-ratio: 1; background: #f0f0f0; }
    .gallery-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.2s; }
    .gallery-thumb:hover img { transform: scale(1.04); }
    .gallery-thumb .thumb-caption { position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(transparent, rgba(0,0,0,0.6)); color: #fff; font-size: 0.7rem; padding: 16px 6px 5px; line-height: 1.2; }
    .doc-card { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 10px; text-decoration: none; margin-bottom: 8px; transition: opacity 0.15s; }
    .doc-card:hover { opacity: 0.82; }
    .doc-card .doc-icon-wrap { font-size: 1.6rem; flex-shrink: 0; width: 36px; text-align: center; }
    .doc-card .doc-label { flex: 1; font-size: 0.9rem; font-weight: 600; line-height: 1.3; }
    .doc-card .doc-arrow { font-size: 1rem; opacity: 0.6; }
    #tl-lightbox { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.93); z-index: 9999; align-items: center; justify-content: center; flex-direction: column; }
    #tl-lb-prev, #tl-lb-next { position: absolute; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,0.15); border: none; color: #fff; font-size: 2rem; width: 44px; height: 44px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.15s; z-index: 2; }
    #tl-lb-prev { left: 12px; }
    #tl-lb-next { right: 12px; }
    #tl-lb-prev:hover, #tl-lb-next:hover { background: rgba(255,255,255,0.3); }
    #tl-lightbox.open { display: flex; }
    #tl-lb-img { max-width: 92vw; max-height: 82vh; border-radius: 10px; object-fit: contain; }
    #tl-lb-caption { color: rgba(255,255,255,0.75); font-size: 0.85rem; margin-top: 10px; text-align: center; max-width: 80vw; }
    #tl-lb-close { position: absolute; top: 16px; right: 20px; color: #fff; font-size: 1.8rem; cursor: pointer; background: none; border: none; line-height: 1; }
  </style>
</head>
<body>

  <div class="hero-band${(t.pattern === "carbon" || t.pattern === "wood") ? " dark-header" : ""}">


    ${heroPhotos}

    <div class="biz-name">${escHtml(p.business_name || "Business Profile")}</div>
    ${p.tagline ? `<div class="tagline">${escHtml(p.tagline)}</div>` : ""}
  </div>

  ${(p.business_name || p.phone) ? `
  <div class="profile-action-bar">
    <button class="action-btn share-btn" onclick="shareProfile()" id="shareBtn" aria-label="Share this profile">
      &#128279; Share
    </button>
    ${p.phone ? `<a class="action-btn" href="tel:${escHtml(p.phone)}" aria-label="Call ${escHtml(p.business_name||'')}">&#128222; Call</a>` : ""}
    <a class="action-btn" href="/.netlify/functions/vcard?handle=${escHtml(p.handle||"")}" target="_blank" rel="noopener" aria-label="Save contact">&#128101; Save Contact</a>
    <button class="action-btn" onclick="showQrModal()" aria-label="Show QR code">&#128247; Show QR</button>
  </div>` : ""}

  ${bioSection}

  ${(phoneSection || customLinks || bookingBtn || menuBtn) ? `
  <div class="card">
    ${p.phone ? `<div class="section-title">Contact</div>${phoneSection}` : ""}
    ${bookingBtn}${menuBtn}
    ${customLinks ? `<div class="section-title" style="margin-top:${(p.phone||bookingBtn||menuBtn) ? "16px" : "0"}">Links</div>${customLinks}` : ""}
  </div>` : ""}

  ${socialLinks ? `
  <div class="card">
    <div class="section-title">Find us on</div>
    ${socialLinks}
  </div>` : ""}

  ${paymentsSection}

  ${videoEmbed}

  ${updatesSection}

  ${menuSection}

  ${servicesSection}

  ${gallerySection}

  ${documentsSection}

  ${buildReviews(p, reviews)}

  ${leadSection}

  <!-- Lightbox -->
  <div id="tl-lightbox" onclick="if(event.target===this)closeLightbox()">
    <button id="tl-lb-close" onclick="closeLightbox()">&times;</button>
    <button id="tl-lb-prev" onclick="lbNav(-1)" aria-label="Previous photo">&#8249;</button>
    <img id="tl-lb-img" src="" alt="" />
    <button id="tl-lb-next" onclick="lbNav(1)" aria-label="Next photo">&#8250;</button>
    <p id="tl-lb-caption"></p>
  </div>

  <!-- QR share overlay -->
  <div class="qr-overlay" id="qrOverlay" onclick="closeQrModal()">
    <button class="qr-overlay-close" onclick="closeQrModal()" aria-label="Close">&times;</button>
    <div class="qr-overlay-box" onclick="event.stopPropagation()">
      <img id="qrOverlayImg" src="" alt="QR Code" />
      <div class="qr-overlay-url">torrolink.com/p/${escHtml(p.handle||'')}</div>
      <div class="qr-overlay-hint">Tap anywhere outside to close</div>
    </div>
  </div>

  <!-- TorroLink CTA bottom -->
  <div class="tl-cta-bottom">
    <div class="tl-cta-powered">Powered by <a href="https://torrolink.com" target="_blank" rel="noopener">Torrolink</a></div>
    <div class="tl-cta-btns">
      <a href="https://torrolink.com/#pricing" target="_blank" rel="noopener" class="tl-cta-btn-primary">&#10024; Get Your QR Profile</a>
      <a href="https://torrolink.com/#pricing" target="_blank" rel="noopener" class="tl-cta-btn-ghost">See Plans &amp; Pricing</a>
    </div>
  </div>

  <script>
    // ── QR overlay ────────────────────────────────────────────────────────────
    function showQrModal() {
      var overlay = document.getElementById('qrOverlay');
      var img = document.getElementById('qrOverlayImg');
      var url = 'https://torrolink.com/p/${escHtml(p.handle||'')}';
      img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' + encodeURIComponent(url) + '&ecc=M&margin=10';
      overlay.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    function closeQrModal() {
      document.getElementById('qrOverlay').classList.remove('open');
      document.body.style.overflow = '';
    }

    // ── No carousel — hero layout is static ──────────────────────────────────

    // ── Lead form ────────────────────────────────────────────────────────
    var leadForm = document.getElementById('leadForm');
    if (leadForm) {
      leadForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        var btn = document.getElementById('leadSubmitBtn');
        btn.disabled = true; btn.textContent = 'Sending…';
        var fd = new FormData(leadForm);
        var payload = {
          profileId: '${escJs(p.id)}',
          name:      fd.get('lead_name'),
          phone:     fd.get('lead_phone'),
          email:     fd.get('lead_email'),
          message:   fd.get('lead_comment'),
          interests: fd.getAll('interests'),
        };
        try {
          var res = await fetch('/.netlify/functions/lead-notify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
          if (!res.ok) throw new Error('Server error ' + res.status);
          document.getElementById('leadSuccess').style.display = 'block';
          leadForm.style.display = 'none';
        } catch {
          btn.disabled = false; btn.textContent = 'Send →';
          alert('Something went wrong. Please try again.');
        }
      });
    }

    // ── Reviews ──────────────────────────────────────────────────────────────
    var _reviewRating = 5;
    function pickStar(n) {
      _reviewRating = n;
      document.querySelectorAll('.star-btn').forEach(function(btn, i) {
        btn.classList.toggle('on', i < n);
      });
    }
    pickStar(5);
    function toggleReviewForm() {
      var f = document.getElementById('reviewForm');
      if (!f) return;
      var open = f.style.display === 'block';
      f.style.display = open ? 'none' : 'block';
      var wb = document.querySelector('.review-write-btn');
      if (wb) wb.textContent = open ? '✏️ Write a Review' : '✕ Cancel';
    }
    async function submitReview(e, profileId) {
      e.preventDefault();
      var btn  = document.getElementById('reviewSubmitBtn');
      var name = document.getElementById('reviewerName').value.trim();
      var text = document.getElementById('reviewerText').value.trim();
      if (!name || !text) { alert('Please enter your name and review.'); return; }
      btn.disabled = true; btn.textContent = 'Sending…';
      try {
        var res = await fetch('/.netlify/functions/review-submit', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ profileId: profileId, name: name, rating: _reviewRating, text: text })
        });
        if (res.ok) {
          document.getElementById('reviewSuccess').style.display = 'block';
          document.getElementById('reviewForm').style.display = 'none';
          document.querySelector('.review-write-btn').style.display = 'none';
          document.getElementById('reviewSuccess').textContent = '✓ Your review is live! Thank you.';
        } else {
          var d = await res.json().catch(function(){ return {}; });
          alert(d.error || 'Failed to submit. Please try again.');
          btn.disabled = false; btn.textContent = 'Submit Review';
        }
      } catch(err) {
        alert('Network error. Please try again.');
        btn.disabled = false; btn.textContent = 'Submit Review';
      }
    }

    // ── Gallery lightbox (with swipe + arrow navigation) ─────────────
    var _lbPhotos = [];
    var _lbIdx    = 0;
    var _lbTouchX = null;

    // Called from gallery thumbs — builds photo array for navigation
    function openLightbox(photoId, url, caption) {
      // Build ordered photo list from rendered thumbs for prev/next
      _lbPhotos = Array.from(document.querySelectorAll('.gallery-thumb')).map(function(el) {
        return { id: el.getAttribute('data-id'), url: el.getAttribute('data-url'), caption: el.getAttribute('data-caption') };
      });
      _lbIdx = _lbPhotos.findIndex(function(p) { return p.id === photoId; });
      if (_lbIdx < 0) _lbIdx = 0;
      _lbShow(photoId, url, caption);
    }

    function _lbShow(photoId, url, caption) {
      document.getElementById('tl-lb-img').src = url;
      document.getElementById('tl-lb-caption').textContent = caption || '';
      var lb = document.getElementById('tl-lightbox');
      lb.classList.add('open');
      document.body.style.overflow = 'hidden';
      // Show/hide arrows
      var prev = document.getElementById('tl-lb-prev');
      var next = document.getElementById('tl-lb-next');
      if (prev) prev.style.display = _lbPhotos.length > 1 ? '' : 'none';
      if (next) next.style.display = _lbPhotos.length > 1 ? '' : 'none';
      // Track view (fire-and-forget)
      if (photoId) {
        fetch('/.netlify/functions/track-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ photoId: photoId })
        }).catch(function(){});
      }
    }

    function lbNav(dir) {
      if (!_lbPhotos.length) return;
      _lbIdx = (_lbIdx + dir + _lbPhotos.length) % _lbPhotos.length;
      var p = _lbPhotos[_lbIdx];
      _lbShow(p.id, p.url, p.caption);
    }

    function closeLightbox() {
      var lb = document.getElementById('tl-lightbox');
      if (lb) { lb.classList.remove('open'); document.getElementById('tl-lb-img').src = ''; }
      document.body.style.overflow = '';
    }

    // Touch swipe for mobile
    (function() {
      var lb = document.getElementById('tl-lightbox');
      if (!lb) return;
      lb.addEventListener('touchstart', function(e) { _lbTouchX = e.touches[0].clientX; }, { passive: true });
      lb.addEventListener('touchend', function(e) {
        if (_lbTouchX === null) return;
        var dx = e.changedTouches[0].clientX - _lbTouchX;
        _lbTouchX = null;
        if (Math.abs(dx) > 40) lbNav(dx < 0 ? 1 : -1);
      });
    })();

    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') lbNav(1);
      if (e.key === 'ArrowLeft') lbNav(-1);
    });

    // ── Share button ──────────────────────────────────────────────────
    function shareProfile() {
      var url  = window.location.href;
      var name = document.title.split(' — ')[0] || 'Check out this profile';
      if (navigator.share) {
        navigator.share({ title: name, url: url }).catch(function(){});
      } else {
        navigator.clipboard.writeText(url).then(function() {
          var btn = document.getElementById('shareBtn');
          if (btn) { btn.textContent = '\u2713 Copied!'; setTimeout(function(){ btn.innerHTML = '&#128279; Share'; }, 2000); }
        }).catch(function() {
          prompt('Copy this link:', url);
        });
      }
    }

    // ── ACTION TRACKING ──────────────────────────────────────────────────────
    (function() {
      var _pid = '${escJs(p.id || "")}';
      if (!_pid) return;
      function trackAction(type, target) {
        try {
          fetch('/track-action', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ profileId: _pid, type: type, target: target || '' }),
            keepalive: true
          });
        } catch(_) {}
      }
      // Phone links
      document.querySelectorAll('a[href^="tel:"]').forEach(function(el) {
        el.addEventListener('click', function() { trackAction('phone_tap', el.getAttribute('href')); });
      });
      // Email links
      document.querySelectorAll('a[href^="mailto:"]').forEach(function(el) {
        el.addEventListener('click', function() { trackAction('email_tap', el.getAttribute('href')); });
      });
      // Save Contact button
      document.querySelectorAll('a[href*="vcard"]').forEach(function(el) {
        el.addEventListener('click', function() { trackAction('save_contact', ''); });
      });
      // External links (skip lead form and lightbox internals)
      document.querySelectorAll('a[href^="http"]').forEach(function(el) {
        if (!el.closest('#leadForm') && !el.closest('.tl-lightbox')) {
          el.addEventListener('click', function() { trackAction('link_tap', el.getAttribute('href')); });
        }
      });
    })();
  </script>
</body>
</html>`;
}

// ── LEAD FORM BUILDER ──────────────────────────────────────────────────────────

function buildLeadForm(p) {
  const checkboxes = (p.lead_form_checkboxes || [])
    .map(opt => `<label class="check-label">
      <input type="checkbox" name="interests" value="${escHtml(opt)}" /> ${escHtml(opt)}
    </label>`).join("");

  const textbox = p.lead_form_has_textbox
    ? `<textarea name="lead_comment" rows="3" placeholder="Tell us what you need…" maxlength="1000"></textarea>` : "";

  return `<div class="card">
    <div class="section-title">Get in Touch</div>
    <form class="lead-form" id="leadForm">
      <input type="text"  name="lead_name"  placeholder="Your name"     required maxlength="100" />
      <input type="tel"   name="lead_phone" placeholder="Phone number" maxlength="30" />
      <input type="email" name="lead_email" placeholder="Email address" maxlength="200" />
      ${checkboxes ? `<div class="checkboxes">${checkboxes}</div>` : ""}
      ${textbox}
      <button type="submit" class="submit-btn" id="leadSubmitBtn">Send →</button>
    </form>
    <div class="form-success" id="leadSuccess">✅ Got it! We'll be in touch soon.</div>
  </div>`;
}

// ── REVIEWS SECTION ───────────────────────────────────────────────────────────

function buildReviews(p, reviews) {
  const stars = n => '★'.repeat(n) + '☆'.repeat(5 - n);

  const ratedRevs  = reviews.filter(r => r.rating);
  const ratingCount = ratedRevs.length;
  const avgRating   = ratingCount > 0
    ? ratedRevs.reduce((s, r) => s + r.rating, 0) / ratingCount
    : null;
  const avgBar = (avgRating && ratingCount >= 2) ? `
    <div class="review-avg-bar">
      <span class="review-avg-score">${avgRating.toFixed(1)}</span>
      <div>
        <div class="review-avg-stars">${'★'.repeat(Math.round(avgRating))}${'☆'.repeat(5 - Math.round(avgRating))}</div>
        <div class="review-avg-label">${ratingCount} review${ratingCount !== 1 ? 's' : ''}</div>
      </div>
    </div>` : '';

  const cards = reviews.map(r => `
    <div class="review-card${r.is_featured ? ' featured' : ''}">
      ${r.is_featured ? '<div class="featured-badge">⭐ Featured</div>' : ''}
      <div class="review-stars">${stars(r.rating || 5)}</div>
      <div class="review-text">&ldquo;${escHtml(r.review_text || '')}&rdquo;</div>
      <div class="review-author">— ${escHtml(r.reviewer_name || 'Anonymous')}</div>
    </div>
  `).join('');

  const empty = !reviews.length
    ? '<p style="font-size:0.85rem;opacity:0.55;text-align:center;padding:6px 0 4px;">No reviews yet — be the first!</p>'
    : '';

  return `<div class="card">
    <div class="section-title">Reviews</div>
    ${avgBar}
    ${cards}
    ${empty}
    <button class="review-write-btn" onclick="toggleReviewForm()">✏️ Write a Review</button>
    <form id="reviewForm" style="display:none;margin-top:16px;" onsubmit="submitReview(event,'${escJs(p.id)}')">
      <div class="star-picker">
        ${[1,2,3,4,5].map(n => `<button type="button" class="star-btn" onclick="pickStar(${n})">★</button>`).join('')}
      </div>
      <input  type="text"  id="reviewerName" placeholder="Your name" required class="review-input" maxlength="100" />
      <textarea id="reviewerText" rows="3" placeholder="Share your experience..." required class="review-input" maxlength="1000"></textarea>
      <button type="submit" class="submit-btn" id="reviewSubmitBtn">Submit Review</button>
    </form>
    <p id="reviewSuccess" style="display:none;text-align:center;color:#0f6b6b;font-weight:700;padding:16px 0;">✓ Thanks for your review!</p>
  </div>`;
}

// ── 404 PAGE ──────────────────────────────────────────────────────────────────

function notFoundPage(handle) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile Not Found — Torrolink</title>
  <meta name="robots" content="noindex" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet" />
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#0f6b6b 0%,#1a2e4a 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;}
    .card{background:#fff;border-radius:24px;padding:48px 36px;max-width:420px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.25);}
    .qr-icon{font-size:4rem;margin-bottom:16px;}
    h1{font-size:1.6rem;font-weight:800;color:#1a1a2e;margin-bottom:10px;}
    p{color:#666;font-size:0.95rem;line-height:1.5;margin-bottom:28px;}
    .handle{color:#0f6b6b;font-weight:700;}
    .btn{display:inline-block;background:#0f6b6b;color:#fff;font-weight:700;font-size:0.95rem;padding:13px 28px;border-radius:50px;text-decoration:none;transition:opacity 0.15s;}
    .btn:hover{opacity:0.88;}
    .btn-ghost{background:none;color:#0f6b6b;border:2px solid #0f6b6b;margin-top:10px;}
    .actions{display:flex;flex-direction:column;gap:10px;align-items:center;}
    .tagline{font-size:0.8rem;color:#aaa;margin-top:24px;}
  </style>
</head>
<body>
  <div class="card">
    <div class="qr-icon">&#128247;</div>
    <h1>This profile doesn't exist</h1>
    <p>We couldn't find a Torrolink profile at <span class="handle">/${escHtml(handle)}</span>. It may have been moved or the QR code may have a typo.</p>
    <div class="actions">
      <a href="https://torrolink.com" class="btn">Visit Torrolink</a>
      <a href="https://torrolink.com/#pricing" class="btn btn-ghost">Get your own QR profile</a>
    </div>
    <p class="tagline">Torrolink — Your Business. One Scan Away.</p>
  </div>
</body>
</html>`;
}

function suspendedPage(businessName) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile Temporarily Unavailable — Torrolink</title>
  <meta name="robots" content="noindex" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet" />
  <style>
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Inter',sans-serif;background:linear-gradient(135deg,#555 0%,#1a1a2e 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;}
    .card{background:#fff;border-radius:24px;padding:48px 36px;max-width:420px;width:100%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.3);}
    .icon{font-size:3.5rem;margin-bottom:16px;}
    h1{font-size:1.5rem;font-weight:800;color:#1a1a2e;margin-bottom:10px;}
    p{color:#666;font-size:0.95rem;line-height:1.5;margin-bottom:24px;}
    a{color:#0f6b6b;font-weight:700;text-decoration:none;}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">&#9200;</div>
    <h1>Temporarily Unavailable</h1>
    <p><strong>${escHtml(businessName)}</strong>'s profile is temporarily unavailable. Please check back soon or contact them directly.</p>
    <p><a href="https://torrolink.com">Powered by Torrolink</a></p>
  </div>
</body>
</html>`;
}

// ── HELPERS ───────────────────────────────────────────────────────────────────

function escHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}

function escJs(str) {
  return String(str || "").replace(/\\/g, "\\\\").replace(/'/g, "\\'");
}
function safeUrl(s) {
  const u = String(s || "").trim();
  if (/^javascript:/i.test(u) || /^data:/i.test(u) || /^vbscript:/i.test(u)) return "#";
  return u;
}

function toEmbedUrl(url) {
  if (!url) return "";
  const yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/);
  if (yt) return `https://www.youtube.com/embed/${yt[1]}`;
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return `https://player.vimeo.com/video/${vm[1]}`;
  return ""; // only allow YouTube and Vimeo embeds
}
